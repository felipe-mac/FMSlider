package com.fms.fmslider

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

//classe necessária para o funcionamento do GLIDE, spós determinada versão precisamos do GlideApp, essa classe configura isso
@GlideModule
class MGlideModule : AppGlideModule()