package com.fms.fmslider

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MotionEvent
import android.widget.RelativeLayout
import com.fms.fmslider.adapter.SliderAdapter
import kotlinx.android.synthetic.main.slider_layout.view.*


public class FMSliderLayout : RelativeLayout {

    constructor(context: Context?) : super(context) {
        LayoutInflater.from(context).inflate(R.layout.slider_layout, this, true)
    }
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        LayoutInflater.from(context).inflate(R.layout.slider_layout, this, true)
    }
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        LayoutInflater.from(context).inflate(R.layout.slider_layout, this, true)
    }

    public fun initImages() {
        val adapter = SliderAdapter()
        viewPager.setAdapter(adapter)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
//        println("==> onIntercept")
        return super.onInterceptTouchEvent(ev)
    }

}