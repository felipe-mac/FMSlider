package com.fms.fmslider.adapter

import android.support.v4.view.PagerAdapter
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.fms.fmslider.GlideApp

public class SliderAdapter : PagerAdapter() {


    override fun isViewFromObject(view: View, obj: Any): Boolean {
        return view == obj
    }

    override fun getCount(): Int {
        return 1
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val imageView = ImageView(container.context)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        GlideApp.with(container.context)
            .load("https\":\"https:\\/\\/static3.tcdn.com.br\\/img\\/img_prod\\/311840\\/camisa_under_armour_sao_paulo_i_2015_14436_1_20190423092319.jpg")
            .into(imageView)
        container.addView(imageView)
        return imageView
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as ImageView)
        super.destroyItem(container, position, `object`)
    }
}